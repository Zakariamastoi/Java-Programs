import java.util.Scanner;
public class Largest{
	public static void main (String[]args){
		//int large;
		Scanner input = new Scanner(System.in);
		int large=0;
		 //int count = input.nextInt();
		for(int count=1; count<=10;count++){
			System.out.print("Enter the Number :");
			int userInput = input.nextInt();
			if(userInput > large){
				large = userInput;
			}//end of if condition
		}
		System.out.printf("%s Largest Number is :", large);
		//System.out.printf("%s Largest Number is :", large);
	}
}