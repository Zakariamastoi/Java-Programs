// Fig. 10.11: Payable.java
// Payable interface declaration.

public interface Payable
{
	double getPaymentAmount(); // calculate payment; no implementation
}