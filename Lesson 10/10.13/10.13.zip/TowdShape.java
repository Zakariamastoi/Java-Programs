public abstract class TowdShape extends Shape
{
	public abstract double getArea();
} // end class TwoDimensionalShape