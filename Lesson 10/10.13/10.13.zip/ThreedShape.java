public abstract class ThreedShape extends Shape
{
	public abstract double getVolume();  
} // end class ThreedShape

    
    